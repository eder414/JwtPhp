<?php
	session_start();
?>
<?php
  if (isset($_POST['btnEliminar'])) {
    unset($_SESSION['usuario']);
	unset($_SESSION['password']);
  }
  elseif(isset($_POST['destruirSessiones'])){
	session_destroy();
	header("Refresh:0");
  }
  elseif(isset($_POST['iniciarSession'])){
	if(isset($_POST['usuario']) && isset($_POST['password'])){
		$usuario = $_POST['usuario'];
		$password = $_POST['password'];
		if($usuario == "Eder" && $password == '123456'){
			$_SESSION['usuario'] = $usuario;
			$_SESSION['password'] = $password;
		}
	}
  }
  
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Curso</title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
  </head>
  <body>
	
    <form action="" method="POST">
		<?php
		if(isset($_SESSION['usuario']) && isset($_SESSION['password'])){
			echo "<h1>usuario: ".$_SESSION['usuario']." - Password: ".$_SESSION['password']."</h1>";
		}
		?>
		<div class="container p-3 col-6 align-self-center p-2 bd-highlight">
			<div class="text-right">
				<button class="btn btn-secondary text-left" name="destruirSessiones">x</button>
			</div>
			<hr>
			<div class="justify-content-sm-center">
				<div class="input-group mb-3">
				  <div class="input-group-prepend">
					<span class="input-group-text" id="label1">Usuario: </span>
				  </div>
				  <?php
					if(isset($_SESSION['usuario'])){
						echo('<input type="text" class="form-control" placeholder="Usuario" name="usuario" aria-label="Usuario" aria-describedby="basic-addon1" value="'.$_SESSION['usuario'].'">');
					}	
					else{
						echo('<input type="text" class="form-control" placeholder="Usuario" name="usuario" aria-label="Usuario" aria-describedby="basic-addon1" >');
					}
					?>
				  
				</div>
			</div>
			<div class="justify-content-sm-center">
				<div class="input-group mb-3">
				  <div class="input-group-prepend">
					<span class="input-group-text" id="label2">Password: </span>
				  </div>
				   <?php
					if(isset($_SESSION['password'])){
						echo('<input type="password" class="form-control" name="password" placeholder="Password" aria-label="Password" aria-describedby="basic-addon1" value="'.$_SESSION['password'].'">');
					}	
					else{
						echo('<input type="password" class="form-control" name="password" placeholder="Password" aria-label="Password" aria-describedby="basic-addon1">');
					}
					?>
				  
				</div>
			</div>
		</div>
		<div class="container p-3 col-6 align-self-center">
			<Button class="btn btn-primary" name="iniciarSession"
					>Ingresar</Button>
					
			<Button class="btn btn-danger" name="btnEliminar"
					>limpiar</Button>
		</div>
	</form>
	<script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-Fy6S3B9q64WdZWQUiU+q4/2Lc9npb8tCaSX9FK7E8HnRr0Jz8D6OP9dO5Vg3Q9ct" crossorigin="anonymous"></script>
  </body>
</html>