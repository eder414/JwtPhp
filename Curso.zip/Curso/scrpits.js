$(document).ready(function(){
	console.log("usuario: ",$(".usuario").val()," password: ",$(".inputElement").val());
  $(".GetValor").click(function(){
    console.log("usuario: ",$(".usuario").val()," password: ",$(".inputElement").val());
  });
});