<?php
require_once "conexion.php";
$Conf = new JConfig;

use Firebase\JWT\JWT;
use Firebase\JWT\Key;
require_once('./vendor/autoload.php');

	/* Conectar a una base de datos de MySQL invocando al controlador */
	/*$dsn = 'mysql:dbname=vote;host=127.0.0.1;charset=utf8';*/
if($_REQUEST['action'] == 'GenerarJWT'){
	$dsn = 'mysql:dbname='.$Conf->db.';host='.$Conf->host.';charset=utf8';
	$usuario =  $Conf->user;
	$contraseña = $Conf->password;



	$datos = json_decode($_REQUEST['datos']);
	

    /*
        @Part List<MultipartBody.Part> Files,
        @Part("nombre") RequestBody nombre,
        @Part("direccion") RequestBody direccion);

        $datos = json_decode($_REQUEST['datos']);
    */
	

	try {
	    $gbd = new PDO($dsn, $usuario, $contraseña);
	} catch (PDOException $e) {
	    echo 'Falló la conexión: ' . $e->getMessage();
	}
	/* Ejecutar una sentencia preparada vinculando varialbes de PHP */
	$sql = 'CALL curso_php.P_login(?,?,@response)';
	$stmt = $gbd->prepare($sql);
	$stmt->bindParam(1, $datos -> correo, PDO::PARAM_STR,45);
	$stmt->bindParam(2, $datos -> password, PDO::PARAM_STR,45);

	$stmt->execute();
	
	$resultado = $stmt->fetchAll();
	
	$responses = new stdClass();
	$vector = array();
    $z = 0;
	foreach ($resultado as $row) {
        array_push($vector, $row);
        $z++;
	}
	$responses -> datos = $vector;
	//GetResponses
	$sql = "SELECT @response as response";
	
	$stmt = $gbd->prepare($sql);
	$stmt->execute();
	$resultado = $stmt->fetchAll();
	
	
	
	foreach ($resultado as $row) {
        $responses -> response = $row[0];
	}
	
	$jtwObject = new stdClass();
	
	
	if($responses -> response == 'OK' ){
		$jtwObject=generateJWT($datos);
	}
	

	$stmt = null;
	$gbd = null;
	$dsn = null;
	echo($jtwObject -> jwtEncode);

    
}
if($_REQUEST['action'] == 'ValidarJwt'){
	$headers = getallheaders();
	
	//echo("headers 1: ".$headers['Authorization']);
	//echo("header: ".json_encode($headers));
	$matches;
	if (! preg_match('/Bearer\s(\S+)/', $headers['Authorization'], $matches)) {
		header('HTTP/1.0 400 Bad Request');
		echo 'Token not found in request';
		exit;
	}
	$jwt = $matches[1];
	if (! $jwt) {
		// No token was able to be extracted from the authorization header
		header('HTTP/1.0 400 Bad Request');
		exit;
	}
	$secret_Key  = '68V0zWFrS72GbpPreidkQFLfj4v9m3Ti+DXc8OB0gcM=';
	//$token = JWT::decode($jwt, $secret_Key, ['HS256']);
	/*
	
	*/
	$serverName = "localhost";
	$now = new DateTimeImmutable();
	$token = JWT::decode($jwt, new Key($secret_Key, 'HS256'));
	//echo(json_encode($decoded));
	//echo("before: ".$token->nbf." expiration: ".$token->exp." date: ".$now->getTimestamp());
	if ($token->iss !== $serverName ||
		$token->nbf > $now->getTimestamp() ||
		$token->exp < $now->getTimestamp())
	{
		header('HTTP/1.1 401 Unauthorized');
		exit;
	}
	else{
		echo ("token valido");
	}
}
function generateJWT($datos){
	
	$jtwObject = new stdClass();
	/*Objecto con cadenas codificadas y decodificadas */

		
		$secret_Key  = '68V0zWFrS72GbpPreidkQFLfj4v9m3Ti+DXc8OB0gcM=';
			$date   = new DateTimeImmutable();
			$expire_at     = $date->modify('+30 minutes')->getTimestamp();      // Add 60 seconds
			$domainName = "localhost";
			$username   = $datos -> correo;                                           // Retrieved from filtered POST data
			$payload = [
				'iat'  => $date->getTimestamp(),         // Issued at: time when the token was generated
				'iss'  => $domainName,                       // Issuer
				'nbf'  => $date->getTimestamp(),         // Not before
				'exp'  => $expire_at,                           // Expire
				'correo' => $datos -> correo,                     // User name
			];
		/**
		 * IMPORTANT:
		 * You must specify supported algorithms for your application. See
		 * https://tools.ietf.org/html/draft-ietf-jose-json-web-algorithms-40
		 * for a list of spec-compliant algorithms.
		 */
		$jwt = JWT::encode($payload, $secret_Key, 'HS256');
		$decoded = JWT::decode($jwt, new Key($secret_Key, 'HS256'));

		//print_r($decoded);

		/*
		 NOTE: This will now be an object instead of an associative array. To get
		 an associative array, you will need to cast it as such:
		*/

		$decoded_array = (array) $decoded;

		/**
		 * You can add a leeway to account for when there is a clock skew times between
		 * the signing and verifying servers. It is recommended that this leeway should
		 * not be bigger than a few minutes.
		 *
		 * Source: http://self-issued.info/docs/draft-ietf-oauth-json-web-token.html#nbfDef
		 */
		JWT::$leeway = 60; // $leeway in seconds
		$decoded = JWT::decode($jwt, new Key($secret_Key, 'HS256'));
		
		
		$jtwObject -> jwtEncode = $jwt;
		$jtwObject -> jwtDecode = $decoded;
		
		
	return $jtwObject;
}
?>
