<?php
	session_start();
?>
<?php
	$dir = "/Curso/";
	$dominio = "localhost";
	$https = false;
	$http = false;
  if (isset($_POST['btnEliminar'])) {
    setcookie('usuario',"",time() - 3600,$dir,$dominio,$https,$http);
	setcookie('password',"",time() - 3600,$dir,$dominio,$https,$http);
	header("Refresh:0");
  }
  elseif(isset($_POST['destruirSessiones'])){
	$cookies = explode(';', $_SERVER['HTTP_COOKIE']);
    foreach($cookies as $cookie) {
        $parts = explode('=', $cookie);
        $name = trim($parts[0]);
        setcookie($name, '', time()-1000,$dir,$dominio,$https,$http);
        setcookie($name, '', time()-1000,$dir,$dominio,$https,$http);
		header("Refresh:0");
    }
  }
  elseif(isset($_POST['iniciarSession'])){
	if(isset($_POST['usuario']) && isset($_POST['password'])){
		setcookie("usuario",$_POST['usuario'],time()+60,$dir,$dominio,$https,$http);
		setcookie("password",$_POST['password'],time()+60,$dir,$dominio,$https,$http);
		header("Refresh:0");
	}
  }
  
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Curso</title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
  </head>
  <body>
	
    <form action="" method="POST" autocomplete="off">
		<?php
		if(isset($_COOKIE['usuario']) && isset($_COOKIE['password'])){
			echo "<h1>usuario: ".$_COOKIE['usuario']." - Password: ".$_COOKIE['password']."</h1>";
		}
		?>
		<div class="container p-3 col-6 align-self-center p-2 bd-highlight">
			<div class="text-right">
				<button class="btn btn-secondary text-left" name="destruirSessiones">x</button>
			</div>
			<hr>
			<div class="justify-content-sm-center">
				<div class="input-group mb-3">
				  <div class="input-group-prepend">
					<span class="input-group-text" id="label1">Usuario: </span>
				  </div>
				  <?php
					if(isset($_COOKIE['usuario'])){
						echo('<input type="text" class="form-control usuario" placeholder="Usuario" name="usuario" aria-label="Usuario" aria-describedby="basic-addon1" value="'.$_COOKIE['usuario'].'">');
					}	
					else{
						echo('<input type="text" class="form-control usuario" placeholder="Usuario" name="usuario" aria-label="Usuario" aria-describedby="basic-addon1" >');
					}
					?>
				  
				</div>
			</div>
			<div class="justify-content-sm-center">
				<div class="input-group mb-3">
				  <div class="input-group-prepend">
					<span class="input-group-text" id="label2">Password: </span>
				  </div>
				   <?php
					if(isset($_COOKIE['password'])){
						echo('<input type="password"  class="form-control inputElement" name="password" placeholder="Password" aria-label="Password" aria-describedby="basic-addon1" value="'.$_COOKIE['password'].'">');
					}	
					else{
						echo('<input type="password" class="form-control inputElement" name="password" placeholder="Password" aria-label="Password" aria-describedby="basic-addon1" value="">');
					}
					?>
				  
				</div>
			</div>
		</div>
		<div class="container p-3 col-6 align-self-center">
			<Button class="btn btn-primary" name="iniciarSession"
					>Ingresar</Button>
					
			<Button class="btn btn-danger" name="btnEliminar"
					>limpiar</Button>
			<Button class="btn btn-danger GetValor" name="btnEliminar" type="button"
					>Valor Elemento</Button>
		</div>
	</form>
	<script src="./jquery-3.6.1.min.js" ></script>
	<script src="./scrpits.js" ></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-Fy6S3B9q64WdZWQUiU+q4/2Lc9npb8tCaSX9FK7E8HnRr0Jz8D6OP9dO5Vg3Q9ct" crossorigin="anonymous"></script>
  </body>
</html>