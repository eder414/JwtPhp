<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Curso</title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
  </head>
  <body>
	
    <form autocomplete="off">
		<div class="container p-3 col-6 align-self-center p-2 bd-highlight">
			<div class="text-right">
				<button class="btn btn-secondary text-left" name="destruirSessiones">x</button>
			</div>
			<hr>
			<div class="justify-content-sm-center">
				<div class="input-group mb-3">
				  <div class="input-group-prepend">
					<span class="input-group-text" id="label1">Correo: </span>
				  </div>
				  <input type="text" class="form-control correo" placeholder="Correo" name="correo" aria-label="Usuario" aria-describedby="basic-addon1" value="">
				  
				</div>
			</div>
			<div class="justify-content-sm-center">
				<div class="input-group mb-3">
				  <div class="input-group-prepend">
					<span class="input-group-text" id="label2">Password: </span>
				  </div>
				   <input type="text" class="form-control password" placeholder="Password" name="Password" aria-label="Password" aria-describedby="basic-addon1" value="">
				</div>
			</div>
		</div>
		<div class="container p-3 col-6 align-self-center">
			<Button type="button" class="btn btn-primary iniciarSession" name="iniciarSession"
					>Ingresar</Button>
					
			<Button type="button" class="btn btn-danger " name="btnEliminar"
					>limpiar</Button>
			<Button type="button" class="btn btn-success validateJwt" name="btnEliminar" type="button"
					>Valor Elemento</Button>
		</div>
	</form>
	<script src="./jquery-3.6.1.min.js" ></script>
	<script src="./jwtScript.js" ></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-Fy6S3B9q64WdZWQUiU+q4/2Lc9npb8tCaSX9FK7E8HnRr0Jz8D6OP9dO5Vg3Q9ct" crossorigin="anonymous"></script>
  </body>
</html>