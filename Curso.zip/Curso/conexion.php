<?php

class JConfig {

   public $dbtype = 'mysqli';

   public $host = '127.0.0.1';

   public $user = 'root';

   public $password = '';

   public $db = 'curso_php';

}

?>