$(document).ready(function(){
	
	$(".correo").val("eder414c@gmail.com");
	$(".password").val("123456");
	$( ".iniciarSession" ).click(function() {
	  //alert("usuario: "+$(".usuario").val());
	  
		  datos = new Object();
		  datos.correo = $(".correo").val();
		  datos.password = $(".password").val();
		  console.log(datos);
		  $.ajax({
			type: "POST",
			url: "WsPhp.php",
			data: { action: "GenerarJWT", datos: JSON.stringify(datos)},
			/*headers: {
				"Authorization": "Bearer eyJraWQiOiJBbWZJSXU3UFhhdXlUbHM3UmNyZmNIQUd1MUdCWkRab2I0U05GaVJuWUFJPSIsImFsZyI6IlYYYjU2In0.eyJzdWIiOiJjNTYyEEE1ZS05Zjc3LTQ2NDAtYTFmOS1hJJJ5Njk1OGE0MzUiLCJhdWQiOiI3Z2ZsZnNmMm1vNnQ4dXJpOG0xcHY5N3BnayIsImVtYWlsX3ZlcmlmaWVkIjp0cnVlLCJldmVudF9pZCI6ImE2YWFjOTQxLTYzYWUtNGU5ZS1iYTE1LTRlYTNlOGIyZjQ5MSIsInRva2VuX3VzZSI6ImlkIiwiYXV0aF90aW1lIjoxNTY4OTY0NDI2LCJpc3MiOiJodHRwczpcL1wvY29nbml0by1pZHAudXMtd2VzdC0yLmFtYXpvbmF3cy5jb21cL3VzLXdlc3QtMl9qanRiZFZkZEYiLCJjb2duaXRvOnVzZXJuYW1lIjoiYzU2MmFjNWUtOWY3Ny00NjQwLWExZjktYTgxOTY5NThhNDM1IiwiZXhwIjoxNTY4OTY4MDI2LCJpYXQiOjE1Njg5NjQ0MjcsImVtYWlsIjoiYnJ5YW5Ab3BlbndvbmsuY29tIn0.fV4bgaKwXx-HjrBmGtBnSzaDHdP0JEeJ0sbE6MzuOJYWafT5gWfh9pLtkpUv-mgsnX3cVIWDVKC0H8_XM4ziUhsulZIRBwTiSca0CfABvanuMdbdjk1iK70aUxsrjHX0gK4SDUi4Zl6JNGws_SRbVi9Yq_ntx7ttXfUpZHjimfZ2mLidOLUruYctG1V_gU-dLD6CARCUbGh5aRk5nwX_5-HBUTbBVPYK3sXcVg2YRk63d-p3TITA5hoOEj9lxtHs3ZM7ZqNPl0XPUGghxdbvWnpSIUKrFLugRHqCiWxC38ZYiBhP0NDYoEMaOI-UrnEH1W6j-kr3fnH2LD5wOMJ_8Q"
			},*/
			beforeSend: function() {
				//$(".boton").text("enciando");
			},
			complete: function(data) {
				// $(".boton").text("enviar");
			},
			success: function(data) {
				console.log("data: "+data);
				localStorage.setItem('jwtToken', data);
			},

			error: function(data) {
				// que hacer si se cumplio la peticiĂ³n
				//alert("falso mapa");
			}
		  });
	});
	$( ".validateJwt" ).click(function() {
		
		var bearer = "Bearer "+localStorage.getItem('jwtToken');
			//var bearer = "Bearer "+"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpYXQiOjE2NjU4NjU3ODAsImlzcyI6ImxvY2FsaG9zdCIsIm5iZiI6MTY2NTg2NTc4MCwiZXhwIjoxNjY1ODY3NTgwLCJjb3JyZW8iOiJlZGVyNDE0Y0BnbWFpbC5jb20ifQ.Yhd_IwM2Zv1MvdYhjJdaNScwdf5UcXaNYpk4B-6aeIQ";
		  $.ajax({
			type: "POST",
			url: "WsPhp.php",
			data: { action: "ValidarJwt"},
			/*headers: {
				"Authorization": bearer
			},*/
			beforeSend: function (xhr){ 
				xhr.setRequestHeader('Authorization', bearer); 
			},
			complete: function(data) {
				// $(".boton").text("enviar");
			},
			success: function(data) {
				console.log("respuesta: "+data);
			},

			error: function(data) {
				// que hacer si se cumplio la peticiĂ³n
				//alert("falso mapa");
			}
		  });
	});
});